package tugas.tugas2;

public class MyClassPrime implements Runnable {

	@Override
	public void run() {
		try {
			Thread.sleep(6000);
			
			for (int i = 2; i < 30 ; i++) {
				boolean bilPrima = true;

				for (int j = 2; j < i; j++) {
					if (i % j == 0) {
						bilPrima = false;
						break;
					}
				}

				if (bilPrima == true) {
					System.out.println("bilangan prima : " + i);
				}
				
				
			}
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}
}
