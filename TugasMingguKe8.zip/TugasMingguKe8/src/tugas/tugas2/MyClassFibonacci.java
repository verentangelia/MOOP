package tugas.tugas2;

public class MyClassFibonacci implements Runnable {

	@Override
	public void run() {
		int a = 0, b = 1, c;
		
		try {
			Thread.sleep(6000);
			
			for (int i = 0; i <= 20; ++i) {
				System.out.println("Bilangan fibonacci : " + a);
				c = a + b;
				a = b;
				b = c;
			}
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	
}
