package tugas.tugas2;

public class Demo {

	public static void main(String[] args){
		Thread prima = new Thread(new MyClassPrime());
		Thread fibo = new Thread(new MyClassFibonacci());
		
		prima.start();
		fibo.start();
	}

}
