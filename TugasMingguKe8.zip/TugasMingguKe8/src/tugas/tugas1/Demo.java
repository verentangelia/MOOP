package tugas.tugas1;

import java.util.Scanner;

public class Demo {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int angka1 = 0;
		
		System.out.println("Input Angka: ");
		angka1 = scan.nextInt(); scan.nextLine();	
		
		MyClassGanjilGenap gg = new MyClassGanjilGenap(angka1);
		Thread thread = new Thread(gg);
		MyClassFibonacci fibo = new MyClassFibonacci(angka1);
		Thread thread2 = new Thread(fibo);
		
		
		thread.start();
		
		try {
			Thread.sleep(30000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		thread2.start();
	}

}
