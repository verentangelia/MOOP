package tugas.tugas1;

public class MyClassFibonacci extends Thread {
	
	private int angka1;

	public int getAngka1() {
		return angka1;
	}



	public void setAngka1(int angka1) {
		this.angka1 = angka1;
	}
	
	
	public MyClassFibonacci(int angka1) {
		super();
		this.angka1 = angka1;
	}


	public void run() {
		try {
			Thread.sleep(30000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		int i = 0;
		int a=0,b=1;
		
		while (i < angka1) {
			i = a + b;
			a = b;
			b = i;
		}
		
		
		if(angka1 == i){
			System.out.println("Angka fibonacci");
		}else{
			System.out.println("Angka bukan fibonacci");
		}
		
		
	}
}
