package tugas.tugas1;

public class MyClassGanjilGenap implements Runnable{
	
	private int angka1;
	
	public int getAngka1() {
		return angka1;
	}



	public void setAngka1(int angka1) {
		this.angka1 = angka1;
	}

	public MyClassGanjilGenap(int angka1) {
		super();
		this.angka1 = angka1;
	}



	@Override
	public void run() {
		try {
			Thread.sleep(30000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(angka1 %2 == 1){
			System.out.println("Angka ganjil");
		}
		else{
			System.out.println("Angka genap");
		}
		
		
	}
	
}