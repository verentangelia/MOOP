
public class Kubus extends BangunRuang{

	public Kubus(double sisi) {
		super(sisi);
		// TODO Auto-generated constructor stub
	}

	@Override
	double luas() {
		// TODO Auto-generated method stub
		return (6*(sisi*sisi));
	}

	@Override
	double keliling() {
		// TODO Auto-generated method stub
		return (12*sisi);
	}

	@Override
	double volume() {
		// TODO Auto-generated method stub
		return (sisi*sisi*sisi);
	}
	
	
}
