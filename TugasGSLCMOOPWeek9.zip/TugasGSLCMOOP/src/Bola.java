
public class Bola extends BangunRuang{

	public Bola(double sisi) {
		super(sisi);
		// TODO Auto-generated constructor stub
	}

	@Override
	double luas() {
		// TODO Auto-generated method stub
		return (Math.PI * 4 * sisi * sisi);
	}

	@Override
	double keliling() {
		// TODO Auto-generated method stub
		return (4/3 * Math.PI * sisi * sisi);
	}

	@Override
	double volume() {
		// TODO Auto-generated method stub
		return (4/3 * Math.PI * sisi * sisi * sisi);
	}

	
	
}
