import java.util.*;

public class Main {
	Scanner scan = new Scanner(System.in);
	int choose;
	int choose2;
	double sisi;
	double sisi2;
	double sisi3;
	double tinggi;

	public Main() {
		do {
			do {
				System.out.println("1. Bangun Datar");
				System.out.println("2. Bangun Ruang");
				System.out.println("3. Exit");
				System.out.print("Choose >> ");
				choose = scan.nextInt();
				scan.nextLine();
			} while (choose < 1 || choose > 3);

			switch (choose) {
			case 1:
				do {
					do {
						System.out.println("1. Persegi");
						System.out.println("2. Persegi Panjang");
						System.out.println("3. Segitiga");
						System.out.println("4. Lingkaran");
						System.out.println("5. Exit");
						System.out.print("Choose >> ");
						choose2 = scan.nextInt();
						scan.nextLine();
					} while (choose2 < 1 || choose > 5);

					if (choose2 == 1) {
						System.out.println("Input sisi: ");
						sisi = scan.nextInt();
						scan.nextLine();

						Persegi persegi = new Persegi(sisi);
						System.out.println("Luas : " + persegi.luas());
						System.out.println("Keliling: " + persegi.keliling());
					}

					else if (choose2 == 2) {
						System.out.println("Input panjang: ");
						sisi = scan.nextInt();
						scan.nextLine();

						System.out.println("Input lebar: ");
						sisi2 = scan.nextInt();
						scan.nextLine();

						Persegi persegip = new Persegi(sisi);
						System.out.println("Luas : " + persegip.luas());
						System.out.println("Keliling: " + persegip.keliling());
					}

					else if (choose2 == 3) {
						System.out.println("Input alas: ");
						sisi = scan.nextInt();
						scan.nextLine();

						System.out.println("Input sisi kanan: ");
						sisi2 = scan.nextInt();
						scan.nextLine();

						System.out.println("Input sisi kiri: ");
						sisi3 = scan.nextInt();
						scan.nextLine();

						System.out.println("input tinggi: ");
						tinggi = scan.nextInt();
						scan.nextLine();

						Segitiga segi3 = new Segitiga(sisi, sisi2, sisi3, tinggi);
						System.out.println("Luas : " + segi3.luas());
						System.out.println("Keliling: " + segi3.keliling());
					}

					else if (choose2 == 4) {
						System.out.println("Input jari-jari: ");
						sisi = scan.nextInt();
						scan.nextLine();

						Lingkaran lingkar = new Lingkaran(sisi);
						System.out.println("Luas : " + lingkar.luas());
						System.out.println("Keliling: " + lingkar.keliling());
					}
				} while (choose2 != 5);
				break;

			case 2:
				do {
					do {
						System.out.println("1. Kubus");
						System.out.println("2. Balok");
						System.out.println("3. Bola");
						System.out.println("4. Exit");
						System.out.print("Choose >> ");
						choose2 = scan.nextInt(); scan.nextLine();
					} while (choose2 < 1 || choose > 4);
					
					if (choose2 == 1) {
						System.out.println("Input sisi: ");
						sisi = scan.nextInt();
						scan.nextLine();

						Kubus kbs = new Kubus(sisi);
						System.out.println("Luas : " + kbs.luas());
						System.out.println("Keliling: " + kbs.keliling());
						System.out.println("Volume: " + kbs.volume());
					}
					
					else if(choose2 == 2){
						System.out.println("Input panjang: ");
						sisi = scan.nextInt(); scan.nextLine();
						
						System.out.println("Input lebar: ");
						sisi2 = scan.nextInt(); scan.nextLine();
						
						System.out.println("Input tinggi: ");
						sisi3 = scan.nextInt(); scan.nextLine();
						
						Balok blk = new Balok(sisi, sisi2, sisi3);
						System.out.println("Luas : " + blk.luas());
						System.out.println("Keliling: " + blk.keliling());
						System.out.println("Volume: " + blk.volume());
					}
					
					else if(choose == 3){
						System.out.println("Input jari-jari: ");
						sisi = scan.nextInt();
						scan.nextLine();
						
						Bola bola = new Bola(sisi);
						System.out.println("Luas : " + bola.luas());
						System.out.println("Keliling: " + bola.keliling());
						System.out.println("Volume: " + bola.volume());
					}
				} while (choose2 != 4);
				break;
			}

		} while (choose != 3);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();
	}

}
