
public class Persegi extends BangunDatar{

	public Persegi(double sisi) {
		super(sisi);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double getSisi() {
		// TODO Auto-generated method stub
		return super.getSisi();
	}

	@Override
	public void setSisi(double sisi) {
		// TODO Auto-generated method stub
		super.setSisi(sisi);
	}

	@Override
	double luas() {
		// TODO Auto-generated method stub
		return (sisi*sisi);
	}

	@Override
	double keliling() {
		// TODO Auto-generated method stub
		return (sisi*4);
	}
	
	
}
