
public class PersegiPanjang extends BangunDatar{

	private double sisi2;

	public double getSisi2() {
		return sisi2;
	}

	public void setSisi2(double sisi2) {
		this.sisi2 = sisi2;
	}

	public PersegiPanjang(double sisi, double sisi2) {
		super(sisi);
		this.sisi2 = sisi2;
	}

	@Override
	public double getSisi() {
		// TODO Auto-generated method stub
		return super.getSisi();
	}

	@Override
	public void setSisi(double sisi) {
		// TODO Auto-generated method stub
		super.setSisi(sisi);
	}

	@Override
	double luas() {
		// TODO Auto-generated method stub
		return (sisi*sisi2);
	}

	@Override
	double keliling() {
		// TODO Auto-generated method stub
		return (2*(sisi+sisi2));
	}
	
	
	
}
