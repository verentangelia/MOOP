
public class BangunRuang extends BangunDatar {

	public BangunRuang(double sisi) {
		super(sisi);
		// TODO Auto-generated constructor stub
	}

	@Override
	double luas() {
		return super.luas();
	}

	@Override
	double keliling() {
		return super.keliling();
	}
	
	double volume(){
		return sisi;
		
	}

}
