
public class Segitiga extends BangunDatar{

	private double sisi2;
	private double sisi3;
	private double tinggi;

	public Segitiga(double sisi, double sisi2, double sisi3, double tinggi) {
		super(sisi);
		this.sisi2 = sisi2;
		this.sisi3 = sisi3;
		this.tinggi = tinggi;
	}

	public double getSisi2() {
		return sisi2;
	}

	public void setSisi2(double sisi2) {
		this.sisi2 = sisi2;
	}

	public double getSisi3() {
		return sisi3;
	}

	public void setSisi3(double sisi3) {
		this.sisi3 = sisi3;
	}

	public double getTinggi() {
		return tinggi;
	}

	public void setTinggi(double tinggi) {
		this.tinggi = tinggi;
	}

	@Override
	public double getSisi() {
		// TODO Auto-generated method stub
		return super.getSisi();
	}

	@Override
	public void setSisi(double sisi) {
		// TODO Auto-generated method stub
		super.setSisi(sisi);
	}

	@Override
	double luas() {
		// TODO Auto-generated method stub
		return (sisi*tinggi/2);
	}

	@Override
	double keliling() {
		return (sisi+sisi2+sisi3);
	}
	
	
}
