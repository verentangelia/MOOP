
public class Balok extends BangunRuang{
	private double sisi2;
	private double sisi3;

	public Balok(double sisi, double sisi2, double sisi3) {
		super(sisi);
		this.sisi2 = sisi2;
		this.sisi3 = sisi3;
	}

	public double getSisi3() {
		return sisi3;
	}

	public void setSisi3(double sisi3) {
		this.sisi3 = sisi3;
	}

	public double getSisi2() {
		return sisi2;
	}

	public void setSisi2(double sisi2) {
		this.sisi2 = sisi2;
	}


	@Override
	double luas() {
		// TODO Auto-generated method stub
		return (2*(sisi*sisi2) + 2*(sisi2*sisi3) + 2*(sisi*sisi3));
	}

	@Override
	double keliling() {
		// TODO Auto-generated method stub
		return (4*(sisi+sisi2+sisi3));
	}

	@Override
	double volume() {
		// TODO Auto-generated method stub
		return (sisi*sisi2*sisi3);
	}
	
	
}
