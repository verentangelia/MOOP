package Tugas.Mingguke5;

public class Lingkaran extends Bangun {
	
	public Lingkaran(int panjang) {
		super(panjang);
		// TODO Auto-generated constructor stub
	}
	
	public double luas(){
		return (3.14 * panjang * panjang);
	}
	
	public double keliling(){
		return (3.14 * 2 *panjang);
	}

	public Lingkaran() {
		// TODO Auto-generated constructor stub
	}

}
