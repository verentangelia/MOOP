package Tugas.Mingguke5;

public class Bola extends Bangun{
	
	public Bola(int panjang) {
		super(panjang);
		// TODO Auto-generated constructor stub
	}
	
	public double luas(){
		return (4 * 3.14 * panjang * panjang);
	}
	
	public double keliling(){
		return (4/3 * 3.14 * panjang * panjang);
	}
	
	public double volume(){
		return (4/3 * 3.14 * panjang * panjang * panjang);
	}

	public Bola() {
		// TODO Auto-generated constructor stub
	}

}
