package Tugas.Mingguke5;

public class Segitiga extends Bangun {
	public int tinggi;
	public int lebar;
	public int sisi2;
	
	
	
	public Segitiga(int panjang, int tinggi, int lebar, int sisi2) {
		super(panjang);
		this.tinggi = tinggi;
		this.lebar = lebar;
		this.sisi2 = sisi2;
	}


	public int getSisi2() {
		return sisi2;
	}


	public void setSisi2(int sisi2) {
		this.sisi2 = sisi2;
	}


	public int getLebar() {
		return lebar;
	}


	public void setLebar(int lebar) {
		this.lebar = lebar;
	}


	public int getTinggi() {
		return tinggi;
	}


	public void setTinggi(int tinggi) {
		this.tinggi = tinggi;
	}

	
	public int luas(){
		return (panjang*tinggi / 2);
	}
	
	public int keliling(){
		return (panjang + lebar + sisi2);
	}


	public Segitiga() {
		// TODO Auto-generated constructor stub
	}

}
