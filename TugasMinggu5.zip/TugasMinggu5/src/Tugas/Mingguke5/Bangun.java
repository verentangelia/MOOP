package Tugas.Mingguke5;

public class Bangun {
	
	public int panjang;
	
	
	
public int getPanjang() {
		return panjang;
	}



	public void setPanjang(int panjang) {
		this.panjang = panjang;
	}



public Bangun(int panjang) {
		super();
		this.panjang = panjang;
	}



//	private int luas;
//	private int keliling;
//	
//	
//	
//	public int getLuas() {
//		return luas;
//	}
//
//	public void setLuas(int newValue) {
//		luas = newValue;
//	}
//
//	public int getKeliling() {
//		return keliling;
//	}
//
//	public void setKeliling(int newValue) {
//		keliling = newValue;
//	}
//	
//	public void print(){
//		System.out.println("Luas: " );
//		System.out.println("Keliling: ");
//	}
//	
//	
//	
//	public Bangun(int luas, int keliling) {
//		super();
//		this.luas = luas;
//		this.keliling = keliling;
//	}

	public Bangun() {
		// TODO Auto-generated constructor stub
	}
	
//	public void luas(){
//		
//	}
//	
//	public void keliling(){
//		
//	}

}
