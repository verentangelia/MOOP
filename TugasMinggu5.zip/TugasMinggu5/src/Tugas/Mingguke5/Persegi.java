package Tugas.Mingguke5;

public class Persegi extends Bangun {
	
	public Persegi(int panjang) {
		super(panjang);
		// TODO Auto-generated constructor stub
	}
	
	public int luas(){
		return (panjang*panjang);
	}
	
	public int keliling(){
		return (4*panjang);
	}

	public Persegi() {
		// TODO Auto-generated constructor stub
	}

}
