package Tugas.Mingguke5;

public class Kubus extends Bangun {
	
	public Kubus(int panjang) {
		super(panjang);
		// TODO Auto-generated constructor stub
	}
	
	public int luas(){
		return ((panjang * panjang)* 6);
	}
	
	public int keliling(){
		return (12*panjang);
	}
	
	public int volume(){
		return (panjang*panjang*panjang);
	}


	public Kubus() {
		// TODO Auto-generated constructor stub
	}

}
