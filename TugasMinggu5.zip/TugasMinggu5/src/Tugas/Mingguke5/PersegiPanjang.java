package Tugas.Mingguke5;

public class PersegiPanjang extends Bangun{

	public int lebar;
	
	
	public PersegiPanjang(int panjang, int lebar) {
		super(panjang);
		this.lebar = lebar;
	}



	public int getLebar() {
		return lebar;
	}



	public void setLebar(int lebar) {
		this.lebar = lebar;
	}

	
	public int luas(){
		return (panjang*lebar);
	}
	
	public int keliling(){
		return ((2*panjang) + (2*lebar));
	}

	public PersegiPanjang() {
		// TODO Auto-generated constructor stub
	}

}
