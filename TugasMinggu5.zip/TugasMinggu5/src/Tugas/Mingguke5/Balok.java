package Tugas.Mingguke5;

public class Balok extends PersegiPanjang {
	
	public int tinggi;
	
	
	
	public Balok(int panjang, int lebar, int tinggi) {
		super(panjang, lebar);
		this.tinggi = tinggi;
	}

	public int luas(){
		return ((4 * panjang * tinggi) + (2 * lebar * tinggi));
	}
	
	public int keliling(){
		return ((4 * panjang) + (4 * lebar) + (4 * tinggi));
	}
	
	public int volume(){
		return (panjang * lebar * tinggi);
	}

	public Balok() {
		// TODO Auto-generated constructor stub
	}

}
