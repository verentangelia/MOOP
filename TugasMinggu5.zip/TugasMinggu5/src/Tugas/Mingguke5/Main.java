package Tugas.Mingguke5;
import java.util.*;


public class Main {
Scanner scan = new Scanner(System.in);
int choose1;
int choose2;
int panjang;
int lebar;
int tinggi;
int sisi2;

	public Main() {
		int choose;
		do {
			do {
				System.out.println("1. Bangun Datar");
				System.out.println("2. Bangun Ruang");
				System.out.println("3. Exit");
				System.out.println("Choose >> ");
				choose = scan.nextInt();
				scan.nextLine();
			} while (choose < 1 || choose > 3);
			switch (choose) {
			case 1:
				datar();
				break;

			case 2:
				ruang();
				break;
			}
		} while (choose != 3);
	}

	public void datar(){
		do {
			do {
				System.out.println("1. Persegi");
				System.out.println("2. Persegi Panjang");
				System.out.println("3. Lingkaran");
				System.out.println("4. Segitiga");
				System.out.println("5. Exit");
				System.out.println("Choose >> ");
				choose1 = scan.nextInt();
				scan.nextLine();
			} while (choose1 < 1 || choose1 > 5);
			if (choose1 == 1) {
				System.out.println("input panjang: ");
				panjang =scan.nextInt(); scan.nextLine();
				
				Persegi persegi = new Persegi(panjang);
				
				System.out.println("Luas = " + persegi.luas());
				System.out.println("Keliling = " + persegi.keliling());
			} else if (choose1 == 2) {
				System.out.println("input panjang: ");
				panjang = scan.nextInt(); scan.nextLine();
				
				System.out.println("input lebar: ");
				lebar = scan.nextInt(); scan.nextLine();
				
				PersegiPanjang ppanjang = new PersegiPanjang(panjang, lebar);
				
				System.out.println("Luas = " + ppanjang.luas());
				System.out.println("Keliling = " + ppanjang.keliling());
			} else if(choose1 == 3){
				System.out.println("input jari-jari: ");
				panjang = scan.nextInt(); scan.nextLine();
				
				Lingkaran lingkar = new Lingkaran(panjang);
				
				System.out.println("Luas = " + (double)lingkar.luas());
				System.out.println("Keliling = " + (double)lingkar.keliling());
			} else if(choose1 == 4){
				System.out.println("input alas: ");
				panjang = scan.nextInt(); scan.nextLine();
				
				System.out.println("input tinggi: ");
				tinggi = scan.nextInt(); scan.nextLine();
				
				System.out.println("input sisi kanan: ");
				lebar = scan.nextInt(); scan.nextLine();
				
				System.out.println("input sisi kiri: ");
				sisi2 = scan.nextInt(); scan.nextLine();
				
				Segitiga segitiga = new Segitiga(panjang, tinggi, lebar, sisi2);
				
				System.out.println("Luas = " + segitiga.luas());
				System.out.println("Keliling = " + segitiga.keliling());
			}
		} while (choose1 != 5);
	}
	
	public void ruang(){
		do {
			do {
				System.out.println("1. Kubus");
				System.out.println("2. Balok");
				System.out.println("3. Bola");
				System.out.println("4. Exit");
				System.out.println("Choose >> ");
				choose2 = scan.nextInt();
				scan.nextLine();
			} while (choose2 < 1 || choose2 > 4);
			if (choose2 == 1) {
				System.out.println("input panjang: ");
				panjang =scan.nextInt(); scan.nextLine();
				
				Kubus kubus = new Kubus(panjang);
				
				System.out.println("Luas = " + kubus.luas());
				System.out.println("Keliling = " + kubus.keliling());
				System.out.println("Volume = " + kubus.volume());
			} else if (choose2 == 2) {
				System.out.println("input panjang: ");
				panjang = scan.nextInt(); scan.nextLine();
				
				System.out.println("input lebar: ");
				lebar = scan.nextInt(); scan.nextLine();
				
				System.out.println("input tinggi: ");
				tinggi = scan.nextInt(); scan.nextLine();
				
				Balok balok = new Balok(panjang, lebar, tinggi);
				System.out.println("Luas = " + balok.luas());
				System.out.println("Keliling = " + balok.keliling());
				System.out.println("Volume = " + balok.volume());
			} else if (choose2 ==3){
				System.out.println("input jari-jari: ");
				panjang = scan.nextInt(); scan.nextLine();
				
				Bola bola = new Bola(panjang);
				
				System.out.println("Luas = " + (double)bola.luas());
				System.out.println("Keliling = " + (double)bola.keliling());
				System.out.println("Volume = " + (double)bola.volume());
			}
		} while (choose2 != 4);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();
	}

}
