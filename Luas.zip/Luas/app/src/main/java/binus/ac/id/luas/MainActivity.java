package binus.ac.id.luas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button btnResPersegiPanjang;
    EditText txtfSisi, txtfSisi2;
    TextView tvResultPersegiPanjang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtfSisi = (EditText)findViewById(R.id.txtfSisi);
        txtfSisi2 = (EditText)findViewById(R.id.txtfSisi2);
        btnResPersegiPanjang = (Button) findViewById(R.id.btnResPersegiPanjang);
        tvResultPersegiPanjang = (TextView)findViewById(R.id.tvResultPersegiPanjang);



        btnResPersegiPanjang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String isitxtfSisi = txtfSisi.getText().toString();
                String isitxtfSisi2 = txtfSisi2.getText().toString();

                double txtfSisi = Double.parseDouble(isitxtfSisi);
                double txtfSisi2 = Double.parseDouble(isitxtfSisi2);

                double hs = LuasPersegiPanjang(txtfSisi, txtfSisi2);
 
                String output = String.valueOf(hs);
                tvResultPersegiPanjang.setText(output.toString());

            }
        });
    }

    public double LuasPersegiPanjang(double sisi, double sisi2) { return sisi * sisi2;}
}
